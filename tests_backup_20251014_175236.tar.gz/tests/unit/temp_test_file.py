#!/usr/bin/env python3
"""Test file with formatting issues."""

# This file has intentional formatting issues to test the CI script


def poorly_formatted_function(x, y, z):
    """This function has poor formatting."""
    return x + y + z


# Missing newline at end
