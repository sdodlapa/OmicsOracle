"""Unit tests for OmicsOracle."""
