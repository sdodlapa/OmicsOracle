"""Unit tests for hybrid search."""
