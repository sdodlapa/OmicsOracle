"""Unit tests for ranking module."""
