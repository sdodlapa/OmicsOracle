"""Unit tests for vector database."""
