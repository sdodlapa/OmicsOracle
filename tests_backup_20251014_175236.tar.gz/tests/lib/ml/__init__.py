"""ML module test initialization."""
