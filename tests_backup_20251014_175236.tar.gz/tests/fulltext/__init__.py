"""Tests for full-text content extraction."""
